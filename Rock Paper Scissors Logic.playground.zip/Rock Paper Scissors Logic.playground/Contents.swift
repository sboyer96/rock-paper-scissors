// Rock, Paper, Scisors game logic
// Ideally, player1Guess would accept user input

import SwiftUI

let options = ["Rock", "Paper", "Scissors"]
var round = 1
var player1Score = 0
var player2Score = 0
var player1Guess: String
var player2Guess: String

while player1Score < 3 && player2Score < 3 {
    player1Guess = options[Int.random(in: 0...2)]
    player2Guess = options[Int.random(in: 0...2)]

    print("Round \(round): You played \(player1Guess), and they played \(player2Guess).")
    
    if player1Guess != player2Guess {
        if (player1Guess == "Rock" && player2Guess == "Scissors") {
            print( "You win round \(round)!" )
            player1Score += 1
        } else if (player1Guess == "Paper" && player2Guess == "Rock") {
            print( "You win round \(round)!" )
            player1Score += 1
        } else if (player1Guess == "Scissors" && player2Guess == "Paper") {
            print( "You win round \(round)!" )
            player1Score += 1
        } else {
            print("You lose round \(round)!")
            player2Score += 1
        }
    } else {
        print("It's a tie for round \(round)!")
    }
    round += 1
}
print("Game over! Final score: Player 1 had \(player1Score) points, Player 2 had \(player2Score) points.")
